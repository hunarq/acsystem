export class Aircraft {
   id: string;
   type: string;
   size: string;
   priority: string;
}
